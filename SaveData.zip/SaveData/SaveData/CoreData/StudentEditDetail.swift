
import UIKit
import CoreData

class StudentEditDetail: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    var getStudentInfo : StudentRecord?

    @IBOutlet weak var imgStudent: UIImageView!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtQualification: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
             self.txtStudentName.text = getStudentInfo?.studentname!
             self.txtAge.text = getStudentInfo?.age!
             self.txtQualification.text = getStudentInfo?.qualification!
             self.txtAddress.text = getStudentInfo?.address!
             self.imgStudent.image = UIImage(data: (getStudentInfo?.studentimage!)!)
        
    }
    
    @IBAction func actionEditForm(_ sender: Any) {
        
        print("save data")
        updateData()
    }
    func updateData(){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        getStudentInfo?.studentname = self.txtStudentName.text
        getStudentInfo?.address = self.txtAddress.text
        getStudentInfo?.age = self.txtAge.text
        getStudentInfo?.qualification = self.txtQualification.text
        if let data = (self.imgStudent.image ?? UIImage()).pngData(){
            getStudentInfo?.studentimage = data
        }
        
        do{
            
            try context.save()
            let alert = UIAlertController(title: "Student Detail", message: "Updated Successfully", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            self.navigationController?.popViewController(animated: true)

                }))
            self.present(alert, animated: true)
            
        }catch{
            
        }
      
       }
    
    @IBAction func AddImageButton(sender : AnyObject) {
          
       let imagecontrollr = UIImagePickerController()
          imagecontrollr.delegate = self
          imagecontrollr.sourceType = UIImagePickerController.SourceType.photoLibrary
          self.present(imagecontrollr,animated: true, completion: nil)

      }
      
      func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          
          self.imgStudent.image = info[UIImagePickerController.InfoKey.originalImage]as? UIImage
          self.dismiss(animated: true, completion: nil)
          print("hello")
      }
    
    
    
}
