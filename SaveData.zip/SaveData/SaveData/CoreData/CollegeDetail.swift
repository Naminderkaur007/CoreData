

import UIKit
import CoreData

class CollegeDetail: UIViewController {

    
    var getCollegeInfo : CollegeName?

    @IBOutlet weak var imgCollege: UIImageView!
    
    @IBOutlet weak var lblCollegeName: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblPinCode: UILabel!
    @IBOutlet weak var lblLandmark: UILabel!
    
    @IBOutlet weak var NoOfStudent: UILabel!
    
    
    
    @IBOutlet weak var actionStudentList: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(getCollegeInfo)
        
        self.lblCollegeName.text = getCollegeInfo?.collegename!
        self.lblState.text = getCollegeInfo?.state!
        self.lblPinCode.text = getCollegeInfo?.pincode!
        self.lblLandmark.text = getCollegeInfo?.landmark!
        
        self.imgCollege.image = UIImage(data: (getCollegeInfo?.collegeimage!)!)

        // Do any additional setup after loading the view.
    }
    

  
    @IBAction func submit(_ sender: Any) {
        
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "StudentList") as! StudentList
        secondViewController.getCollegeInfo = getCollegeInfo
        self.navigationController?.pushViewController(secondViewController, animated: true)
        
    }
    
}
