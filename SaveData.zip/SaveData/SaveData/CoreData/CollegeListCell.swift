

import UIKit

class CollegeListCell: UITableViewCell {

  //  @IBOutlet weak var imgCollege: UIImageView!
    @IBOutlet weak var lblCollegeName: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblPincode: UILabel!
    @IBOutlet weak var lblLandmark: UILabel!
 //   @IBOutlet weak var btnAddStudent: UIButton!
    @IBOutlet weak var lblTotalStudents: UILabel!
    
}
extension CollegeListCell: ReusableIdentifier {}
