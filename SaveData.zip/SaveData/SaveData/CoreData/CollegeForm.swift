
import UIKit
import CoreData

class CollegeForm : UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var imgCollege: UIImageView!
    @IBOutlet weak var txtCollegeName: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtPinCode: UITextField!
    @IBOutlet weak var txtLandMark: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnSelectImg: UIButton!
    

    override func viewDidLoad() {
         super.viewDidLoad()
        
        self.stackView.setCustomSpacing(5.0, after: self.imgCollege)

       
    }
    

    @IBAction func AddImageButton(sender : AnyObject) {
        
     let imagecontrollr = UIImagePickerController()
        imagecontrollr.delegate = self
        imagecontrollr.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(imagecontrollr,animated: true, completion: nil)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        self.imgCollege.image = info[UIImagePickerController.InfoKey.originalImage]as? UIImage
        self.dismiss(animated: true, completion: nil)
        print("hello")
    }
 
   
    @IBAction func actionSubmitForm(_ sender: Any) {
        
        print("btn pressed")
        
         //As we know that container is set up in the AppDelegates so we need to refer that container.
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                let managedContext = appDelegate.persistentContainer.viewContext
                let userEntity = NSEntityDescription.insertNewObject(forEntityName: "CollegeName", into: managedContext) as! CollegeName
        
        
        
        userEntity.collegename = self.txtCollegeName.text
        userEntity.state = self.txtState.text
        userEntity.pincode = self.txtPinCode.text
        userEntity.landmark = self.txtLandMark.text
        if let data = (self.imgCollege.image ?? UIImage()).pngData(){
            userEntity.collegeimage = data
        }
                
                do {
                    try managedContext.save()
                    print("Successfully saved data")
                  
                    let alert = UIAlertController(title: "College Form", message: "Data Saved Successfully", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in

                       print("ok then")
                        self.txtCollegeName.text = ""
                        self.txtState.text = ""
                        self.txtLandMark.text = ""
                        self.txtPinCode.text = ""
                        
                        self.navigationController?.popViewController(animated: true)
                        
                    }))
                    self.present(alert, animated: true)
                    
                   
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
        
        
            }
            
}

